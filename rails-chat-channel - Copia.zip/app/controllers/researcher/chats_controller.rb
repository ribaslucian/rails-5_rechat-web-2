class Researcher::ChatsController < Researcher::ResearcherController

  def private
    #@contact = Contact.find params[:contact_id]
  end
  
end
