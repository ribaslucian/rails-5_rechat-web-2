class Researcher::ResearcherController < ApplicationController

  layout 'researcher'
  
end