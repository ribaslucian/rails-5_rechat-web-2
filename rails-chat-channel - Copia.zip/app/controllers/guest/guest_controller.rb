class Guest::GuestController < ApplicationController

  layout 'guest'
  
end
