class Voluntary::VoluntaryController < ApplicationController
  
  layout 'voluntary'
  
end
