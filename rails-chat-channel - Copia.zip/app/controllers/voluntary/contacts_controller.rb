class Voluntary::ContactsController < Voluntary::VoluntaryController

  def index
    
  end
    
end
