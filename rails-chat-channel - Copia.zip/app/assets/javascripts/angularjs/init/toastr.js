/**
 * https://github.com/Foxandxss/angular-toastr
 */
// app.config(function (toastrConfig) {
//     angular.extend(toastrConfig, {
//         timeout: 10000,
//         messageClass: 'small-text-3 bold-1',
//         progressBar: true,
//         preventOpenDuplicates: true,
//         positionClass: 'toast-top-center'
//
// //        customTemplate: '\n\
// //        <div class="{{toastClass}} {{toastType}}" ng-click="tapToast()">\n\
// //        <div ng-switch on="allowHtml">\n\
// //            <div ng-switch-default ng-if="title" class="{{titleClass}}" aria-label="{{title}}">{{title}}</div>\n\
// //            <div ng-switch-default class="{{messageClass}}" aria-label="{{message}}">{{message}}</div>\n\
// //            <div ng-switch-when="true" ng-if="title" class="{{titleClass}}" ng-bind-html="title"></div>\n\
// //            <div ng-switch-when="true" class="{{messageClass}} small-text-6" ng-bind-html="message"></div>\n\
// //          </div>\n\
// //          <progress-bar ng-if="progressBar"></progress-bar>\n\
// //        </div>\n\
// //        '
//     });
// });
