class Contact < ApplicationRecord
  belongs_to :user
end
