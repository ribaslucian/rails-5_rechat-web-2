class MessageInteraction < ApplicationRecord
  
#  belongs_to :user, dependent: :destroy
#  belongs_to :message, dependent: :destroy
  
end
